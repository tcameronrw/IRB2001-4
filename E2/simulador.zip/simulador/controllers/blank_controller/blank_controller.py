from controller import Robot
import numpy as np
import cv2
import argparse
from perception import perception
from threading import Thread

robot = Robot()
TIMESTEP = int(robot.getBasicTimeStep())
RANGOS_INICIALES = [
    ("DELANTE", (0, 0, 255), {"H": [170, 10], "S": [85, 255], "V": [60, 255]}),
    ("ATRAS", (255, 0, 0), {"H": [95, 135], "S": [70, 255], "V": [50, 255]}),
    ("BALON", (0, 255, 255), {"H": [20, 40], "S": [85, 255], "V": [90, 255]}),
]

left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setPosition(float('inf'))
right_motor.setVelocity(4.0)

switch = 0
while robot.step(TIMESTEP) != -1:
    # Check if there is a new image from the Supervisor
    with open('../referee_supervisor/raw_files/camera_b.raw', 'rb') as f:
        raw_data = f.read()

    # Convert raw data to a NumPy array
    img = np.frombuffer(raw_data, dtype=np.uint8)
    img = img.reshape((720, 1280, 3))
    img = img[:, :, :3]
######### Perception ############  
    perception(img)    
##################################
    cv2.imshow('Imagen', img)
    cv2.waitKey(1)


